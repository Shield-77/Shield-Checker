# SHIELD Checker pour Nintendo 3DS / 2DS

SHIELD Checker aide a comprendre l'etat de sa console avec des mots simples. C'est un outil de consultation pour Old 3DS en priorite. Il ne repare rien, n'installe aucun CIA et ne modifie ni la NAND, ni le firmware, ni les reglages systeme.

## Modes

- **Verification rapide** : modele, version systeme, memoire de la region application, version active de Luma, presence de GodMode9 et des outils SD pris en charge, batterie par paliers 0-5 et detection de la SD.
- **Verification standard** : ajoute l'espace SD libre/total et la presence du dossier homebrew /3ds.
- **Diagnostic complet** : ajoute la position du volume, la detection du casque, le signal Wi-Fi et le curseur 3D si le modele le permet. Le test HTTPS est facultatif avec R. Les temperatures CPU/batterie ne sont pas inventees : elles sont indiquees comme non prises en charge.
- **Versions des outils** : conserve les controles de Luma3DS, GodMode9, Universal Updater, SHIELD Updater et hShop/3hs. Le resultat local est disponible sans reseau ; X compare avec les sources officielles via HTTPS.
- **Aide au diagnostic** : huit symptomes avec observations et causes possibles. Aucun verdict materiel certain n'est tire d'un seul indice.

Les verifications ont lieu quand on ouvre un mode. Les resultats restent en memoire pendant la session. La carte SD n'est pas analysee en continu. Les requetes HTTPS ne telechargent aucun programme et peuvent etre annulees avec B. Les depots consultes sont fixes dans source/main.c.

## Tests interactifs

Dans Diagnostic complet, X ouvre le test des touches, du Circle Pad et du tactile. B revient. Une touche non pressee n'est pas consideree comme defectueuse. Y ouvre le test visuel : A change de couleur, X bascule entre ecran superieur et inferieur. L'utilisateur regarde lui-meme les ecrans ; Checker n'annonce pas de panne automatiquement.

## Commandes

- A : ouvrir un menu, un resultat ou un detail.
- Haut/Bas : choisir une option ou un resultat.
- B : retour ; pendant une requete reseau, annuler.
- X : comparaison en ligne dans Versions ; test des commandes dans Diagnostic complet.
- Y : test des couleurs dans Diagnostic complet.
- R : test HTTPS facultatif dans Diagnostic complet.
- START : quitter, sauf pendant le test des commandes pour permettre sa verification.

Dans Reglages, A bascule entre vue simple et avancee ; la vue avancee montre aussi la source technique du resultat. X change la langue francais/anglais. Seul le choix de langue est enregistre dans sdmc:/3ds/ShieldChecker/ui-language.dat. Au premier lancement, la langue suggeree doit etre confirmee ; maintenir X au demarrage rouvre cette confirmation.

## Comprendre les limites

La RAM affichee concerne la region memoire des applications, pas toute la RAM physique de la console. Le niveau de batterie est un palier de 0 a 5, pas un pourcentage ni une mesure d'usure. La position du volume et la detection du casque ne prouvent pas que les haut-parleurs fonctionnent. Un signal Wi-Fi faible ne prouve pas une panne. L'absence de GodMode9 dans les chemins controles n'est pas un probleme si l'utilisateur n'en a pas besoin. Quand Checker ne peut pas verifier quelque chose, il l'indique clairement.

Pour Shield Updater, la revision interne du CIA ne permet pas de lire le numero de release public installe. Checker indique donc la presence de l'application et, si le reseau fonctionne, la derniere release publiee, sans pretendre qu'une mise a jour est necessaire. Checker ne qualifie aucune mise a jour de correctif de securite sans preuve verifiable.

## Identite et compilation

- Title ID conserve : 000400000A210600
- Version CIA interne de cette version de developpement : 6
- Version publique precedente : v1.0.3
- Musique d'ambiance desactivee, sans initialisation DSP pour cette fonction.

Necessite devkitPro/devkitARM, libctru, libcurl, Jansson, mbedTLS, bannertool et makerom. Les executables tiers bannertool et makerom ne sont pas redistribues dans l'archive source ; voir LICENSES/BUILD-TOOLS.md. La licence de la police utilisee est conservee dans assets/LICENSE-AtkinsonHyperlegible.txt.

Compilation : make -j1

Sorties : build/ShieldChecker.cia et build/ShieldChecker.elf.

La banniere HOME provient de `assets/banner-source.png` (256x128, ratio 2:1). Le splash du haut provient de `assets/boot-top-source.png` ; un recadrage central conserve les proportions pour l'ecran 400x240. `tools/prepare_visuals.ps1` regenere `banner.png` et `romfs/boot-top.bgr` sans modifier `icon.png`.

Cette version compile localement. Les nouveaux diagnostics doivent encore etre testes sur une vraie Old 3DS avant publication.
