# SHIELD Checker v1.1.0-dev - version CIA interne 6

- Splash de demarrage sur l'ecran superieur : nouvelle image SHIELD Checker.
- Nouvelle banniere HOME SHIELD Checker.
- Proportions preservees : banniere 2:1, splash recadre au centre pour 400x240.
- L'icone HOME et le Title ID `000400000A210600` restent identiques.
- Le code de diagnostic de la version interne 5 est conserve.

Compilation locale seulement ; un essai sur vraie Old 3DS reste necessaire.
