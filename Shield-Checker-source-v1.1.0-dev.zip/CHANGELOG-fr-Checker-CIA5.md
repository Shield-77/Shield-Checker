# SHIELD Checker v1.1.0-dev - version CIA interne 5

- Trois modes de diagnostic local : rapide, standard et complet.
- Informations reelles du modele, de la version systeme, de la region memoire application, de la batterie, de la SD et des outils installes.
- Mode complet : position du volume, detection du casque, signal Wi-Fi, curseur 3D et limites clairement indiquees pour les temperatures.
- Test HTTPS facultatif avec distinction DNS, TLS, delai depasse et erreur serveur ; annulation avec B.
- Assistant de diagnostic de huit symptomes, avec hypotheses explicables et sans verdict materiel automatique.
- Test interactif des commandes et test visuel de couleurs sur les deux ecrans.
- Interface francais/anglais, vue simple/avancee et resultats de session.
- Les cinq verifications de versions existantes et le Title ID 000400000A210600 sont conserves.
- Les resultats non obtenus indiquent « non verifie » : ils ne signalent pas une panne.
- Shield Updater est detecte sur la SD, mais sa version publique locale n'est pas deduite de la revision interne du CIA.
- Aucun avertissement de vulnerabilite ou de mise a jour de securite n'est emis sans preuve.
- Aucune ecriture systeme ; seule la preference de langue propre a Checker peut etre enregistree sur SD.

Compilation locale reussie. Test sur console Old 3DS requis avant une release publique.
