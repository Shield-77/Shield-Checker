#pragma once

#include <stdbool.h>

// Optional background music. Failure must not prevent Checker from working.
bool music_start(void);
void music_stop(void);
