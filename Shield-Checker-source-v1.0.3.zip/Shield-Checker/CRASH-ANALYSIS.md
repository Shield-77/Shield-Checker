# Crash ARM11 à l'entrée de l'installation CIA

Rapport reçu : PC `0x001B8F70`, SP `0x07FFFEC0`, FAR `0x07FFFEB8`, Data Abort en écriture.

L'ELF archivé avant correction dans `build/crash-2026-10-23-before-stack-fix/ShieldUniversalUpdater.elf` donne :

```text
arm-none-eabi-addr2line -a -f -C -i -e ShieldUniversalUpdater.elf 0x001B8F70 0x00102DD4
0x001b8f70: fopen (bibliothèque, sans ligne de source)
0x00102dd4: install_cia, source/main.c:735
```

Le désassemblage de l'ancien ELF montre que `install_cia()` soustrait `0x8000` (32 Ko) puis 28 octets à SP avant d'appeler `fopen()`. À `0x001B8F70`, la première instruction de `fopen()` est `push {r4, lr}` et écrit précisément à `SP-8`, soit `0x07FFFEB8`, l'adresse fautive. Le crash se produit donc avant `AM_StartCiaInstall`, `FSFILE_Write` et `AM_FinishCiaInstall`. Il est attribuable à l'épuisement de la pile provoqué par le tampon local de 32 Ko à cet endroit. La taille de pile déclarée dans le RSF n'a pas empêché l'accès à une page non mappée sur la console.

Correction : tampon de 32 Ko alloué sur le tas, avec traitement de l'échec d'allocation et libération sur chaque sortie. Les résultats des appels AM et FS, le nombre d'octets écrits et les étapes principales sont consignés dans `sdmc:/3ds/ShieldUpdater/install.log`. La version interne du CIA passe de 1 à 2. L'ancien CIA et son ELF restent dans `build/crash-2026-10-23-before-stack-fix/` ; les nouveaux sont dans `build/`.

Après compilation, le code de `install_cia()` est intégré par le compilateur à `main()` ; la trame de pile de `main()` n'est que de 228 octets et le tampon est obtenu par `malloc(32768)`. Le CIA a été contrôlé pour l'identifiant `000400000A210400`, la version 2 et les empreintes internes. Un test sur Old 3DS/2DS reste nécessaire pour confirmer la disparition du crash et le résultat réel de l'installation AM.
