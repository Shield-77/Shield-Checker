# Shield Universal Updater — version CIA 5

- L'Updater vérifie sa propre release GitHub dès le lancement, avant les autres applications Shield.
- Si une version plus récente existe, il prévient l'utilisateur, puis la télécharge, vérifie sa taille, son SHA-256 et son identifiant CIA, et l'installe automatiquement.
- À la fin de sa propre mise à jour, un message demande de quitter avec START et de relancer l'application.
- La version de chaque release déjà inspectée est mémorisée par empreinte pour éviter de retélécharger le même CIA à chaque lancement.
- La version du programme en cours est prise en compte pour empêcher l'installation d'une ancienne release si la console ne renvoie pas la version installée.
- L'Updater apparaît désormais dans sa liste, avec son logo.
- Les erreurs locales et d'installation affichent « Contacter Shield77 si cela persiste. » ; les erreurs de réseau et de Wi-Fi restent identifiées séparément.

La version CIA 4 déjà installée ne contient pas l'auto-mise à jour : installer cette version CIA 5 une fois avec FBI. Les prochaines releases pourront ensuite être installées automatiquement au lancement. Publier le fichier sous le nom `ShieldUniversalUpdater.cia` dans une nouvelle release du dépôt `Shield-77/Shield-Updater`.
