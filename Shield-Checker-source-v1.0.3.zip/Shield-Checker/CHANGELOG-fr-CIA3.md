﻿# Shield Checker — améliorations

- Vérifie en lecture seule Luma3DS, GodMode9, Universal Updater, Shield Updater et hShop/3hs.
- Compare la version installée sur la SD avec la dernière version stable connue pour chaque application prise en charge.
- Garde hShop/3hs factuel : présence et version uniquement, sans consigne de mise à jour.
- Corrige le rafraîchissement des deux écrans pendant la vérification réseau et réduit les rafraîchissements inutiles.
- Raccourcit proprement les textes de l’écran supérieur pour éviter leur débordement.
- Conserve le fonctionnement hors ligne : la présence locale reste consultable et les comparaisons réseau indiquent « statut indisponible ».
- Reste en lecture seule : aucun fichier ou titre de la console n’est modifié.
