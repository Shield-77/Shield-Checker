﻿# Shield Checker — CIA 2

- Distingue la version Luma active de la présence de `boot.firm` sur la SD. L'absence du fichier SD ne devient pas une alerte si Luma a démarré depuis CTRNAND.
- Cherche GodMode9 dans les chemins de payload courants et indique la présence du dossier `gm9` comme facultative.
- Affiche clairement que l'application est encore en développement et que les chemins contrôlés ne couvrent pas toutes les configurations.
- Reste en lecture seule : aucun téléchargement, aucune installation et aucune modification de fichier.
