# Audio credits and licenses

The same five supplied tracks are bundled in Shield Universal Updater and Shield Optimised Converter. The files are included unchanged and decoded at runtime to stereo 22.05 kHz.

1. **Cat Caffe** (`01-cat-caffe.mp3`) — TAD, “Lofi Compilation”, CC0 1.0. Source: https://opengameart.org/content/lofi-compilation
2. **Chill (Loopable)** (`02-chillloopable.mp3`) — Pro Sensory / Alex McCulloch, CC0 1.0; credit Alex McCulloch as requested by the creator. Source: https://opengameart.org/content/chill-loopable
3. **Chill lofi inspired (loop edit)** (`03-chill-lofi-loop.ogg`) — qubodup, CC0 1.0. Source: https://opengameart.org/content/chill-lofi-inspired-loop-edit
4. **Warm Horizon** (`04-warm-horizon.mp3`) — Purrple Cat, CC BY 4.0. Source: https://purrplecat.itch.io/mellow-skies
5. **Blue Boi** (`05-blue-boi.mp3`) — Lakey Inspired, CC BY-SA 3.0 as identified on the supplied track's Newgrounds source page. Source: https://www.newgrounds.com/audio/listen/1068377

The Blue Boi source page describes the track as a remix. It is bundled unchanged with attribution and the stated CC BY-SA notice; the upstream material is not bundled separately. If the rights holder or upstream source requires another notice, replace this track before redistribution.

## MP3 decoder

`minimp3.h` and `minimp3_ex.h` are by lieff and dedicated to the public domain under CC0 1.0. Source: https://github.com/lieff/minimp3

## OGG decoder

OGG playback uses Tremor from devkitPro's 3DS portlibs. Its license and notices are supplied by the installed portlibs package.
