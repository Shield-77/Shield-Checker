# Outils de construction externes

Le CIA est construit avec `makerom` et `bannertool`. Leurs executables ne font pas partie de l'archive source Shield Checker v1.0.3. Obtenez-les separement aupres de leurs projets, verifiez leurs conditions de distribution et placez les versions Windows dans `tools/makerom.exe` et `tools/bannertool.exe` avant `make`.

- makerom : https://github.com/3DSGuy/Project_CTR
- bannertool : https://github.com/carstene1ns/3ds-bannertool

La police Atkinson Hyperlegible est accompagnee de sa licence SIL OFL dans `assets/LICENSE-AtkinsonHyperlegible.txt`.
