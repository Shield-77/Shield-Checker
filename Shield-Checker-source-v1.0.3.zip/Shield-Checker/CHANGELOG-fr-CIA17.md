# Shield Universal Updater — version CIA 17

- Ajoute **Shield Online Art [EXPERIMENTAL]** à la liste des applications.
- Récupère sa release depuis `Shield-77/Shield-Online-Art` et cherche l'asset exact `ShieldOnlineArt.cia`.
- Vérifie le Title ID `000400000A210500`, qui correspond au CIA v0.1.3 publié.
- Passe au cache `version-cache-v5.txt` afin que les anciens index d'applications ne soient pas attribués aux mauvaises entrées après l'ajout.
- Conserve les comportements de téléchargement, de validation et d'auto-mise à jour de Shield Updater v1.1.11.

Build compilé pour 3DS/2DS ; validation sur console réelle encore nécessaire.
