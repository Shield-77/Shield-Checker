"""Prepare the supplied boot art for the two native 3DS framebuffers."""

from pathlib import Path

from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
ROMFS = ROOT / "romfs"


def main() -> None:
    source = ROOT / "assets" / "boot-bottom-original.png"
    art = Image.open(source).convert("RGB")
    art = art.resize((320, 240), Image.Resampling.LANCZOS)
    pixels = art.load()
    out = bytearray(320 * 240 * 3)
    for x in range(320):
        for y in range(240):
            r, g, b = pixels[x, y]
            at = (x * 240 + (239 - y)) * 3
            out[at : at + 3] = bytes((b, g, r))
    (ROMFS / "boot-bottom.bgr").write_bytes(out)

    icon = Image.open(ROOT / "icon.png").convert("RGB")
    icon = icon.resize((48, 48), Image.Resampling.LANCZOS)
    (ROMFS / "updater-icon.rgb").write_bytes(icon.tobytes())


if __name__ == "__main__":
    main()
