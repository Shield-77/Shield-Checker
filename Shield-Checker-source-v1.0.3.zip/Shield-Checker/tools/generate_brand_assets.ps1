$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing

$projectRoot = Split-Path -Parent $PSScriptRoot
$navy = [System.Drawing.Color]::FromArgb(5, 18, 34)
$cyan = [System.Drawing.Color]::FromArgb(28, 204, 237)
$white = [System.Drawing.Color]::FromArgb(244, 249, 255)
$muted = [System.Drawing.Color]::FromArgb(115, 160, 189)

function Save-CheckerIcon([string]$path) {
    $bitmap = [System.Drawing.Bitmap]::new(48, 48, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $graphics.Clear($navy)
    $border = [System.Drawing.Pen]::new($muted, 1)
    $ring = [System.Drawing.Pen]::new($cyan, 3)
    $check = [System.Drawing.Pen]::new($white, 3.5)
    $handle = [System.Drawing.Pen]::new($cyan, 4)
    $graphics.DrawRectangle($border, 1, 1, 46, 46)
    $graphics.DrawEllipse($ring, 7, 6, 29, 29)
    $graphics.DrawLine($handle, 30, 30, 40, 40)
    $graphics.DrawLine($check, 14, 20, 20, 26)
    $graphics.DrawLine($check, 20, 26, 30, 14)
    $bitmap.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
    $check.Dispose(); $handle.Dispose(); $ring.Dispose(); $border.Dispose()
    $graphics.Dispose(); $bitmap.Dispose()
}

function Save-CheckerBanner([string]$path) {
    $bitmap = [System.Drawing.Bitmap]::new(256, 128, [System.Drawing.Imaging.PixelFormat]::Format24bppRgb)
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $graphics.Clear($navy)
    $circuit = [System.Drawing.Pen]::new([System.Drawing.Color]::FromArgb(28, 43, 65), 1)
    $outline = [System.Drawing.Pen]::new($cyan, 2)
    $thin = [System.Drawing.Pen]::new([System.Drawing.Color]::FromArgb(25, 116, 151), 1)
    $graphics.DrawLine($thin, 0, 20, 49, 20)
    $graphics.DrawLine($thin, 0, 105, 49, 105)
    $graphics.DrawLine($thin, 208, 21, 255, 21)
    $graphics.DrawLine($thin, 208, 105, 255, 105)
    $graphics.DrawEllipse($circuit, 8, 12, 44, 44)
    $graphics.DrawEllipse($circuit, 205, 70, 43, 43)
    $graphics.DrawEllipse($outline, 17, 37, 38, 38)
    $graphics.DrawLine($outline, 45, 66, 59, 80)
    $graphics.DrawLine($outline, 27, 56, 34, 63)
    $graphics.DrawLine($outline, 34, 63, 46, 49)
    $titleFont = [System.Drawing.Font]::new('Segoe UI', 18, [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
    $subFont = [System.Drawing.Font]::new('Segoe UI', 8, [System.Drawing.FontStyle]::Regular, [System.Drawing.GraphicsUnit]::Pixel)
    $bodyFont = [System.Drawing.Font]::new('Segoe UI', 7, [System.Drawing.FontStyle]::Regular, [System.Drawing.GraphicsUnit]::Pixel)
    $whiteBrush = [System.Drawing.SolidBrush]::new($white)
    $cyanBrush = [System.Drawing.SolidBrush]::new($cyan)
    $mutedBrush = [System.Drawing.SolidBrush]::new($muted)
    $graphics.DrawString('SHIELD', $titleFont, $whiteBrush, 65, 31)
    $graphics.DrawString('CHECKER', $titleFont, $cyanBrush, 137, 31)
    $graphics.DrawString('3DS SYSTEM STATUS', $subFont, $mutedBrush, 67, 63)
    $graphics.DrawLine($outline, 67, 82, 190, 82)
    $graphics.DrawString('READ ONLY  |  VERSION CHECK', $bodyFont, $whiteBrush, 67, 91)
    $bitmap.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
    $mutedBrush.Dispose(); $cyanBrush.Dispose(); $whiteBrush.Dispose()
    $bodyFont.Dispose(); $subFont.Dispose(); $titleFont.Dispose()
    $thin.Dispose(); $outline.Dispose(); $circuit.Dispose()
    $graphics.Dispose(); $bitmap.Dispose()
}

Save-CheckerIcon (Join-Path $projectRoot 'icon.png')
Save-CheckerBanner (Join-Path $projectRoot 'banner.png')
